Most of the sample code in this directory requires a connection to the Pubs database. The Pubs database is installed in version 6.5 and 7.0 of SQL Server.


Connecting to the databases
---------------------------
To enable the code sample to connect, you must first create a DSN (Data Source Name) called "Pubs".  This is done by selecting the ODBC applet in the control panel of the machine the code will be running on and following the instruction in the wizard.

The MultiRecordsets.asp page requires that a full connection be used with the sqloledb provider.  This is because the functionality is only available in SQL Server.  The following connection string is the same one from the page.  

	"Provider=sqloledb;Data Source=wpr;Initial Catalog=pubs;User 
	 Id=sa;Password=;"

Remember to adjust the connection to fit your environment. Change the Data Source to the name of your server, and set the proper User ID and Password.


Extra Table
-----------
The InvalidSQlInsert.asp page requires a new table to be added to the Pubs database.  This is used to work with a table that does not have any referential integrity set on it.  The new table name is "Test", which is comprised of a single field called Test.  The Test field is if type varchar, with the length of 50.


Extra Stored Procedures
-----------------------
The SampleMultiRecordset stored procedure is sample stored procedure that is required by the MultiRecordsets.asp page.  This stored procedure (as noted in chapter 16) is used to return multiple recordsets back to the ASP code.

The following is the SQL script used to create the stored procedure

Create Procedure SampleMultiRecordset As
-- update a record (1st Recordset)
UPDATE		Publishers
SET		pub_name = 'Wrox Press',
		City = NULL,
		State = NULL,
		country = 'UK'
WHERE		pub_id = '9901'

-- select records (2nd Recordset)
SELECT		*
FROM		Publishers
ORDER BY	Pub_Name


The RefreshCommand.asp page also requires a stored procedure to demonstrate the refresh method on the Command object.  The following is the SQL script to generate the stored procedure, "AddAuthor"

Create Procedure AddAuthor
	(
		@ID varchar(11),
		@LastName varchar(40),
		@FirstName varchar(20),
		@Phone char(12),
		@Address varchar(40),
		@City varchar(20),
		@State char(2),
		@Zip char(5),
		@Contract bit
	)
As
	INSERT INTO Authors
		(
			au_id,
			au_lname,
			au_fname,
			phone,
			address,
			city,
			state,
			zip,
			contract
		)
	VALUES
		(
			@ID,
			@LastName,
			@FirstName,
			@Phone,
			@Address,
			@City,
			@State,
			@Zip,
			@Contract
		)


