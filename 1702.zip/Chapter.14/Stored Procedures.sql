SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

create procedure up_parmins_boatclass (@name varchar(50), @length int, @weight int,
	@mainjib int, @spinnaker int, @authority varchar(16)) as 

insert into boatclass
	(ClassName, ClassBoatLength, ClassBoatWeight, ClassSailAreaMainJib, ClassSailAreaSpinnaker, ClassAuthority)
	values(@name, @length, @weight, @mainjib, @spinnaker, @authority)

GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  ON    SET ANSI_NULLS  ON 
GO

CREATE procedure up_parmins_boatclass_rc (@name varchar(50), @length int, @weight int,
	@mainjib int, @spinnaker int, @authority varchar(16)) as 

insert into boatclass
	(ClassName, ClassBoatLength, ClassBoatWeight, ClassSailAreaMainJib, ClassSailAreaSpinnaker, ClassAuthority)
	values(@name, @length, @weight, @mainjib, @spinnaker, @authority)

if @@error <> 0
	return @@error
else
	return 0




GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

create procedure up_parmsel_boats (@class varchar(50)) as

select boatsid, boatname
	from boats
	where boatclass = @class

GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

create procedure up_parmupd_boat_certification (@class varchar(50)) as

update boats
	set boatcertified = 1
	where boatclass = @class
return @@rowcount

GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

create procedure up_select_count_of_people as
declare @rc int
select @rc=count(peopleid) from people
return @rc

GO
SET QUOTED_IDENTIFIER  OFF    SET ANSI_NULLS  ON 
GO

